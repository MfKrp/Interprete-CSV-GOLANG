# CASOS_DE_PRUEBA.md — Batería de Evaluación para CSV Copilot

Este documento contiene las consultas de prueba en lenguaje natural, las operaciones estructuradas esperadas, los parámetros exactos y los resultados verificados matemáticamente contra los 10 archivos CSV generados.

> **Convención de operaciones del motor Go:**
> - `count_rows`: `{ "op": "count_rows" }`
> - `count_distinct`: `{ "op": "count_distinct", "column": "<col>" }`
> - `count_filtered`: `{ "op": "count_filtered", "filter": { "column": "<col>", "operator": "<eq|neq|contains|gt|gte|lt|lte>", "value": <val> } }`
> - `sum`: `{ "op": "sum", "column": "<col>" }`
> - `average`: `{ "op": "average", "column": "<col>" }`
> - `min`: `{ "op": "min", "column": "<col>" }`
> - `max`: `{ "op": "max", "column": "<col>" }`
> - `group_by`: `{ "op": "group_by", "group_column": "<col>", "agg": "<count|sum>", "target_column": "<col_opcional>" }`

---

## Dataset 1: `01_biblioteca.csv` (45 registros, 7 columnas)
**Columnas:** `id_libro`, `titulo`, `autor`, `genero`, `editorial`, `anio_publicacion`, `disponible`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 1.1 | ¿Cuántos libros hay registrados en total? | `count_rows` | - | `{}` | `45` |
| 1.2 | ¿Cuántos autores diferentes existen en el catálogo? | `count_distinct` | `autor` | `{"column": "autor"}` | `10` |
| 1.3 | ¿Qué cantidad de ejemplares figuran como disponibles (`Si`)? | `count_filtered` | `disponible` | `{"column": "disponible", "operator": "eq", "value": "Si"}` | `32` |
| 1.4 | ¿Cuántos libros no están disponibles actualmente? | `count_filtered` | `disponible` | `{"column": "disponible", "operator": "neq", "value": "Si"}` | `13` |
| 1.5 | ¿Cuántos títulos contienen la palabra o fragmento `"de"` (sensible a mayúsculas)? | `count_filtered` | `titulo` | `{"column": "titulo", "operator": "contains", "value": "de"}` | `20` *(21 si es case-insensitive)* |
| 1.6 | ¿Cuántos libros fueron publicados después del año 2000? | `count_filtered` | `anio_publicacion` | `{"column": "anio_publicacion", "operator": "gt", "value": 2000}` | `15` |
| 1.7 | ¿Cuál es la suma de todos los años de publicación? | `sum` | `anio_publicacion` | `{"column": "anio_publicacion"}` | `89255` |
| 1.8 | ¿Cuál es el promedio del año de publicación de los libros? | `average` | `anio_publicacion` | `{"column": "anio_publicacion"}` | `1983.44` |
| 1.9 | ¿Cuál es el año de publicación más antiguo y el más reciente? | `min` / `max` | `anio_publicacion` | `{"column": "anio_publicacion"}` | Mín: `1940` / Máx: `2024` |
| 1.10 | ¿Qué cantidad de libros corresponde a cada género? | `group_by` | `genero` | `{"group_column": "genero", "agg": "count"}` | `Ficción: 16, Ciencia Ficción: 15, Terror: 9, Cuentos: 4, Fantasía: 1` |

---

## Dataset 2: `02_recursos_humanos.csv` (55 registros, 8 columnas)
**Columnas:** `legajo`, `empleado`, `departamento`, `puesto`, `ciudad`, `antiguedad`, `salario`, `modalidad`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 2.1 | ¿Cuál es la dotación total de empleados en la nómina? | `count_rows` | - | `{}` | `55` |
| 2.2 | ¿Cuántos departamentos distintos tiene la empresa? | `count_distinct` | `departamento` | `{"column": "departamento"}` | `6` |
| 2.3 | ¿Cuántas personas trabajan en el área de Ingeniería? | `count_filtered` | `departamento` | `{"column": "departamento", "operator": "eq", "value": "Ingeniería"}` | `18` |
| 2.4 | ¿Cuántos empleados tienen una modalidad distinta a Remoto? | `count_filtered` | `modalidad` | `{"column": "modalidad", "operator": "neq", "value": "Remoto"}` | `18` |
| 2.5 | ¿Cuántos puestos incluyen la palabra `"Desarrollador"`? | `count_filtered` | `puesto` | `{"column": "puesto", "operator": "contains", "value": "Desarrollador"}` | `12` |
| 2.6 | ¿Cuántos trabajadores perciben un salario superior a 1.500.000? | `count_filtered` | `salario` | `{"column": "salario", "operator": "gt", "value": 1500000}` | `33` |
| 2.7 | ¿Cuánto suma la masa salarial total de la compañía? | `sum` | `salario` | `{"column": "salario"}` | `87501000` |
| 2.8 | ¿Cuál es el sueldo promedio del personal? | `average` | `salario` | `{"column": "salario"}` | `1590927.27` |
| 2.9 | ¿Cuál es la antigüedad mínima y el salario máximo registrado? | `min` / `max` | `antiguedad` / `salario` | `{"column": "antiguedad"}` / `{"column": "salario"}` | Mín antigüedad: `0` / Máx salario: `2293000` |
| 2.10 | ¿Cuánto suma el salario agrupado por cada departamento? | `group_by` | `departamento`, `salario` | `{"group_column": "departamento", "agg": "sum", "target_column": "salario"}` | `Ingeniería: 34426000, Producto: 15847000, Ventas: 12564000, Soporte: 8702000, Recursos Humanos: 8205000, Finanzas: 7757000` |

---

## Dataset 3: `03_inventario.csv` (60 registros, 7 columnas)
**Columnas:** `codigo_articulo`, `descripcion`, `categoria`, `proveedor`, `stock`, `precio`, `deposito`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 3.1 | ¿Cuántos artículos distintos hay cargados en el inventario? | `count_rows` | - | `{}` | `60` |
| 3.2 | ¿Con cuántos proveedores diferentes operamos? | `count_distinct` | `proveedor` | `{"column": "proveedor"}` | `5` |
| 3.3 | ¿Cuántos ítems están almacenados en el Depósito Central? | `count_filtered` | `deposito` | `{"column": "deposito", "operator": "eq", "value": "Depósito Central"}` | `24` |
| 3.4 | ¿Cuántos productos no pertenecen a la categoría Electrónica? | `count_filtered` | `categoria` | `{"column": "categoria", "operator": "neq", "value": "Electrónica"}` | `50` |
| 3.5 | ¿Cuántos artículos tienen `"Modelo 5"` en su descripción? | `count_filtered` | `descripcion` | `{"column": "descripcion", "operator": "contains", "value": "Modelo 5"}` | `3` |
| 3.6 | ¿Cuántos productos tienen un stock crítico menor o igual a 10 unidades? | `count_filtered` | `stock` | `{"column": "stock", "operator": "lte", "value": 10}` | `14` |
| 3.7 | ¿Cuál es la suma total de unidades en stock? | `sum` | `stock` | `{"column": "stock"}` | `5639` |
| 3.8 | ¿Cuál es el precio promedio de los artículos? | `average` | `precio` | `{"column": "precio"}` | `245.04` |
| 3.9 | ¿Cuál es el precio más bajo y el stock más alto? | `min` / `max` | `precio` / `stock` | `{"column": "precio"}` / `{"column": "stock"}` | Mín precio: `11.15` / Máx stock: `241` |
| 3.10 | ¿Cuántos artículos hay por cada categoría? | `group_by` | `categoria` | `{"group_column": "categoria", "agg": "count"}` | `Periféricos: 16, Electrónica: 10, Redes: 10, Almacenamiento: 8, Cables y Adaptadores: 8, Energía: 8` |

---

## Dataset 4: `04_transporte.csv` (50 registros, 8 columnas)
**Columnas:** `id_viaje`, `conductor`, `tipo_vehiculo`, `origen`, `destino`, `distancia_km`, `duracion_minutos`, `estado`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 4.1 | ¿Cuántos viajes se registraron en la planilla? | `count_rows` | - | `{}` | `50` |
| 4.2 | ¿Cuántos conductores únicos realizaron viajes? | `count_distinct` | `conductor` | `{"column": "conductor"}` | `8` |
| 4.3 | ¿Cuántos traslados figuran con estado Completado? | `count_filtered` | `estado` | `{"column": "estado", "operator": "eq", "value": "Completado"}` | `37` |
| 4.4 | ¿Cuántos viajes tienen un estado distinto a Cancelado? | `count_filtered` | `estado` | `{"column": "estado", "operator": "neq", "value": "Cancelado"}` | `47` |
| 4.5 | ¿Cuántos recorridos se hicieron con un vehículo que contenga `"Camión"`? | `count_filtered` | `tipo_vehiculo` | `{"column": "tipo_vehiculo", "operator": "contains", "value": "Camión"}` | `24` |
| 4.6 | ¿Cuántos viajes tuvieron una distancia mayor o igual a 400 km? | `count_filtered` | `distancia_km` | `{"column": "distancia_km", "operator": "gte", "value": 400}` | `19` |
| 4.7 | ¿Cuántos kilómetros se recorrieron en total entre todos los viajes? | `sum` | `distancia_km` | `{"column": "distancia_km"}` | `18018.9` |
| 4.8 | ¿Cuál es la duración media en minutos de los viajes? | `average` | `duracion_minutos` | `{"column": "duracion_minutos"}` | `270.64` |
| 4.9 | ¿Cuál fue la duración mínima y la distancia máxima? | `min` / `max` | `duracion_minutos` / `distancia_km` | `{"column": "duracion_minutos"}` / `{"column": "distancia_km"}` | Mín duración: `34` / Máx distancia: `751.4` |
| 4.10 | ¿Cuántos kilómetros totales se acumulan agrupando por ciudad de destino? | `group_by` | `destino`, `distancia_km` | `{"group_column": "destino", "agg": "sum", "target_column": "distancia_km"}` | `Córdoba: 6543.2, Mar del Plata: 3309.0, Mendoza: 2576.6, Rosario: 2457.0, San Juan: 1503.0, Posadas: 965.9, Santa Fe: 509.6, Resistencia: 154.6` |

---

## Dataset 5: `05_observatorio_exoplanetas.csv` (40 registros, 9 columnas — Dominio No Convencional)
**Columnas:** `designacion_catalogo`, `sector_celeste`, `metodo_deteccion`, `masa_joviana`, `periodo_orbital_dias`, `temp_equilibrio_k`, `distancia_anios_luz`, `zona_habitable`, `anio_descubrimiento`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 5.1 | ¿Cuántos exoplanetas figuran en el catálogo del observatorio? | `count_rows` | - | `{}` | `40` |
| 5.2 | ¿Cuántos sectores celestes diferentes se analizaron? | `count_distinct` | `sector_celeste` | `{"column": "sector_celeste"}` | `7` |
| 5.3 | ¿Cuántos cuerpos celestes se encuentran en zona habitable (`True`)? | `count_filtered` | `zona_habitable` | `{"column": "zona_habitable", "operator": "eq", "value": "True"}` | `8` |
| 5.4 | ¿Cuántos planetas fueron hallados por un método distinto a Tránsito? | `count_filtered` | `metodo_deteccion` | `{"column": "metodo_deteccion", "operator": "neq", "value": "Tránsito"}` | `19` |
| 5.5 | ¿Cuántas designaciones de catálogo contienen el código `"CYG"`? | `count_filtered` | `designacion_catalogo` | `{"column": "designacion_catalogo", "operator": "contains", "value": "CYG"}` | `5` |
| 5.6 | ¿Cuántos exoplanetas superan las 5.0 masas jovianas? | `count_filtered` | `masa_joviana` | `{"column": "masa_joviana", "operator": "gt", "value": 5.0}` | `27` |
| 5.7 | ¿Cuál es la suma de las distancias en años luz de todos los objetos? | `sum` | `distancia_anios_luz` | `{"column": "distancia_anios_luz"}` | `64125.1` |
| 5.8 | ¿Cuál es la temperatura de equilibrio promedio en Kelvin? | `average` | `temp_equilibrio_k` | `{"column": "temp_equilibrio_k"}` | `1370.78` |
| 5.9 | ¿Cuál es el período orbital más corto y la masa joviana más grande? | `min` / `max` | `periodo_orbital_dias` / `masa_joviana` | `{"column": "periodo_orbital_dias"}` / `{"column": "masa_joviana"}` | Mín período: `57.9` / Máx masa: `12.354` |
| 5.10 | ¿Cuántos descubrimientos corresponden a cada método de detección? | `group_by` | `metodo_deteccion` | `{"group_column": "metodo_deteccion", "agg": "count"}` | `Tránsito: 21, Velocidad Radial: 14, Imagen Directa: 4, Microlente: 1` |

---

## Dataset 6: `06_calidad_aire.csv` (48 registros, 7 columnas)
**Columnas:** `registro_id`, `estacion_monitoreo`, `pm25_ug_m3`, `pm10_ug_m3`, `temperatura_c`, `humedad_pct`, `indice_calidad`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 6.1 | ¿Cuántas mediciones ambientales tiene el archivo? | `count_rows` | - | `{}` | `48` |
| 6.2 | ¿Cuántas estaciones de monitoreo distintas reportaron datos? | `count_distinct` | `estacion_monitoreo` | `{"column": "estacion_monitoreo"}` | `4` |
| 6.3 | ¿Cuántos registros arrojaron un índice de calidad `Buena`? | `count_filtered` | `indice_calidad` | `{"column": "indice_calidad", "operator": "eq", "value": "Buena"}` | `8` |
| 6.4 | ¿Cuántas lecturas no provienen de la estación `EST-PARQUE`? | `count_filtered` | `estacion_monitoreo` | `{"column": "estacion_monitoreo", "operator": "neq", "value": "EST-PARQUE"}` | `37` |
| 6.5 | ¿Cuántas filas tienen `"INDUSTRIAL"` en el nombre de la estación? | `count_filtered` | `estacion_monitoreo` | `{"column": "estacion_monitoreo", "operator": "contains", "value": "INDUSTRIAL"}` | `17` |
| 6.6 | ¿Cuántas muestras registraron niveles de PM2.5 mayores a 50? | `count_filtered` | `pm25_ug_m3` | `{"column": "pm25_ug_m3", "operator": "gt", "value": 50}` | `21` |
| 6.7 | ¿Cuánto suman todas las mediciones de PM10? | `sum` | `pm10_ug_m3` | `{"column": "pm10_ug_m3"}` | `4690.6` |
| 6.8 | ¿Cuál es la temperatura promedio registrada? | `average` | `temperatura_c` | `{"column": "temperatura_c"}` | `22.65` |
| 6.9 | ¿Cuál es la humedad mínima y el pico máximo de PM2.5? | `min` / `max` | `humedad_pct` / `pm25_ug_m3` | `{"column": "humedad_pct"}` / `{"column": "pm25_ug_m3"}` | Mín humedad: `32` / Máx PM2.5: `139.8` |
| 6.10 | ¿Cuántas mediciones realizó cada estación de monitoreo? | `group_by` | `estacion_monitoreo` | `{"group_column": "estacion_monitoreo", "agg": "count"}` | `EST-INDUSTRIAL: 17, EST-CENTRO: 14, EST-PARQUE: 11, EST-PUERTO: 6` |

---

## Dataset 7: `07_clinica_veterinaria.csv` (36 registros, 6 columnas)
**Columnas:** `historia_clinica`, `especie`, `edad_meses`, `peso_kg`, `motivo_consulta`, `costo_atencion`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 7.1 | ¿Cuántas consultas veterinarias están cargadas? | `count_rows` | - | `{}` | `36` |
| 7.2 | ¿Cuántos motivos de consulta diferentes existen? | `count_distinct` | `motivo_consulta` | `{"column": "motivo_consulta"}` | `5` |
| 7.3 | ¿Cuántos pacientes atendidos son de especie Canino? | `count_filtered` | `especie` | `{"column": "especie", "operator": "eq", "value": "Canino"}` | `21` |
| 7.4 | ¿Cuántas atenciones corresponden a animales que no son Felino? | `count_filtered` | `especie` | `{"column": "especie", "operator": "neq", "value": "Felino"}` | `25` |
| 7.5 | ¿Cuántas consultas incluyen la palabra `"Control"` en su motivo? | `count_filtered` | `motivo_consulta` | `{"column": "motivo_consulta", "operator": "contains", "value": "Control"}` | `9` |
| 7.6 | ¿Cuántos pacientes tienen menos de 24 meses de edad? | `count_filtered` | `edad_meses` | `{"column": "edad_meses", "operator": "lt", "value": 24}` | `3` |
| 7.7 | ¿Cuál es la recaudación total por costo de atención? | `sum` | `costo_atencion` | `{"column": "costo_atencion"}` | `1673000` |
| 7.8 | ¿Cuál es el peso promedio en kilos de los animales atendidos? | `average` | `peso_kg` | `{"column": "peso_kg"}` | `17.11` |
| 7.9 | ¿Cuál es el peso mínimo y el costo de atención máximo? | `min` / `max` | `peso_kg` / `costo_atencion` | `{"column": "peso_kg"}` / `{"column": "costo_atencion"}` | Mín peso: `1.81` / Máx costo: `120000` |
| 7.10 | ¿Cuánto suma el costo de atención agrupado por especie? | `group_by` | `especie`, `costo_atencion` | `{"group_column": "especie", "agg": "sum", "target_column": "costo_atencion"}` | `Canino: 1001000, Felino: 516000, Exótico: 156000` |

---

## Dataset 8: `08_torneos_esports.csv` (52 registros, 8 columnas)
**Columnas:** `match_code`, `titulo_juego`, `region_competitiva`, `equipo_ganador`, `duracion_seg`, `espectadores_pico`, `premio_usd`, `fase_torneo`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 8.1 | ¿Cuántas partidas competitivas hay en el registro? | `count_rows` | - | `{}` | `52` |
| 8.2 | ¿Cuántos equipos ganadores únicos aparecen en la tabla? | `count_distinct` | `equipo_ganador` | `{"column": "equipo_ganador"}` | `8` |
| 8.3 | ¿Cuántos encuentros se disputaron en la región `LAS`? | `count_filtered` | `region_competitiva` | `{"column": "region_competitiva", "operator": "eq", "value": "LAS"}` | `14` |
| 8.4 | ¿Cuántas partidas no pertenecen a la fase de `Grupos`? | `count_filtered` | `fase_torneo` | `{"column": "fase_torneo", "operator": "neq", "value": "Grupos"}` | `30` |
| 8.5 | ¿Cuántos matches corresponden a un juego que contenga `"Counter"`? | `count_filtered` | `titulo_juego` | `{"column": "titulo_juego", "operator": "contains", "value": "Counter"}` | `10` |
| 8.6 | ¿Cuántas transmisiones alcanzaron o superaron los 100.000 espectadores pico? | `count_filtered` | `espectadores_pico` | `{"column": "espectadores_pico", "operator": "gte", "value": 100000}` | `33` |
| 8.7 | ¿Cuánto dinero en premios (USD) se repartió en total? | `sum` | `premio_usd` | `{"column": "premio_usd"}` | `207500` |
| 8.8 | ¿Cuál es la duración promedio en segundos de las partidas? | `average` | `duracion_seg` | `{"column": "duracion_seg"}` | `2192.46` |
| 8.9 | ¿Cuál fue el pico mínimo y máximo de espectadores? | `min` / `max` | `espectadores_pico` | `{"column": "espectadores_pico"}` | Mín: `9819` / Máx: `241950` |
| 8.10 | ¿Cuánto suma el premio en dólares por cada título de juego? | `group_by` | `titulo_juego`, `premio_usd` | `{"group_column": "titulo_juego", "agg": "sum", "target_column": "premio_usd"}` | `Valorant: 90500, League of Legends: 64000, Counter-Strike 2: 39500, Rocket League: 13500` |

---

## Dataset 9: `09_valores_problematicos.csv` (35 registros, 8 columnas — Robustez)
**Columnas:** `id_registro`, `categoria`, `sub_categoria`, `monto_bruto`, `monto_neto`, `codigo_ref`, `codigo_revision`, `observacion`

> **Nota para QA:** Este archivo contiene espacios en blanco al inicio/final (`" SOPORTE "`, `"ventas "`), diferencias de capitalización (`"Soporte"`, `"soporte"`), celdas vacías en `monto_neto` (5 vacías), `sub_categoria` y `observacion`, además de columnas con prefijos idénticos (`monto_bruto` vs `monto_neto` y `codigo_ref` vs `codigo_revision`).

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 9.1 | ¿Cuántas filas tiene este archivo? | `count_rows` | - | `{}` | `35` |
| 9.2 | ¿Cuántas categorías únicas exactas detecta sin normalizar espacios/mayúsculas? | `count_distinct` | `categoria` | `{"column": "categoria"}` | `6` *(si hace trim+lower: `4`)* |
| 9.3 | ¿Cuántos registros tienen exactamente `"Soporte"` (con S mayúscula y sin espacios)? | `count_filtered` | `categoria` | `{"column": "categoria", "operator": "eq", "value": "Soporte"}` | `8` *(si ignora espacios/case: `26`)* |
| 9.4 | ¿Cuántas filas tienen una categoría distinta a `"Ventas"` exacto? | `count_filtered` | `categoria` | `{"column": "categoria", "operator": "neq", "value": "Ventas"}` | `31` |
| 9.5 | ¿Cuántas observaciones contienen la palabra `"urgente"`? | `count_filtered` | `observacion` | `{"column": "observacion", "operator": "contains", "value": "urgente"}` | `5` |
| 9.6 | ¿Cuántos registros tienen un `monto_bruto` mayor a 10.000? | `count_filtered` | `monto_bruto` | `{"column": "monto_bruto", "operator": "gt", "value": 10000}` | `14` |
| 9.7 | ¿Cuánto suma la columna `monto_bruto`? | `sum` | `monto_bruto` | `{"column": "monto_bruto"}` | `7634590.3` |
| 9.8 | ¿Cuánto suma `monto_neto` (ignorando las 5 celdas vacías)? | `sum` | `monto_neto` | `{"column": "monto_neto"}` | `6007419.27` |
| 9.9 | ¿Cuál es el valor mínimo y máximo de `monto_bruto`? | `min` / `max` | `monto_bruto` | `{"column": "monto_bruto"}` | Mín: `0.05` / Máx: `1250000.0` |
| 9.10 | ¿Cuántos registros hay agrupados por `categoria` (valores crudos)? | `group_by` | `categoria` | `{"group_column": "categoria", "agg": "count"}` | `soporte: 11, Soporte: 8, ' SOPORTE ': 7, Ventas: 4, 'ventas ': 3, Legales: 2` |

---

## Dataset 10: `10_dataset_limite.csv` (7 registros, 6 columnas — Casos Límite)
**Columnas:** `id_unico`, `estado_fijo`, `categoria`, `valor_numerico`, `columna_vacia`, `puntaje`

| # | Pregunta en Lenguaje Natural | Operación | Columna(s) | Parámetros Esperados | Resultado Exacto |
|---|---|---|---|---|---|
| 10.1 | ¿Cuántos registros tiene esta tabla pequeña? | `count_rows` | - | `{}` | `7` |
| 10.2 | ¿Cuántos valores distintos hay en `estado_fijo` (todos iguales)? | `count_distinct` | `estado_fijo` | `{"column": "estado_fijo"}` | `1` |
| 10.3 | ¿Cuántos valores distintos hay en `id_unico` (todos diferentes)? | `count_distinct` | `id_unico` | `{"column": "id_unico"}` | `7` |
| 10.4 | ¿Cuántos registros pertenecen a la categoría `A`? | `count_filtered` | `categoria` | `{"column": "categoria", "operator": "eq", "value": "A"}` | `4` |
| 10.5 | ¿Cuántas filas tienen una categoría distinta de `A`? | `count_filtered` | `categoria` | `{"column": "categoria", "operator": "neq", "value": "A"}` | `3` |
| 10.6 | ¿Cuántos `id_unico` contienen el carácter `"0"`? | `count_filtered` | `id_unico` | `{"column": "id_unico", "operator": "contains", "value": "0"}` | `7` |
| 10.7 | ¿Cuántos elementos tienen un `valor_numerico` mayor o igual a 40? | `count_filtered` | `valor_numerico` | `{"column": "valor_numerico", "operator": "gte", "value": 40}` | `4` |
| 10.8 | ¿Cuál es la suma y el promedio de `valor_numerico`? | `sum` / `average` | `valor_numerico` | `{"column": "valor_numerico"}` | Suma: `280` / Promedio: `40.0` |
| 10.9 | ¿Cuál es el mínimo y máximo de `valor_numerico`? | `min` / `max` | `valor_numerico` | `{"column": "valor_numerico"}` | Mín: `10` / Máx: `70` |
| 10.10 | ¿Qué cantidad corresponde a cada `categoria`? | `group_by` | `categoria` | `{"group_column": "categoria", "agg": "count"}` | `A: 4, B: 2, C: 1` |

---

## Pruebas Negativas, Ambiguas e Inválidas (Control de Alucinaciones y Límites)

Estas consultas deben ser **rechazadas** por el validador en Go o mediante una respuesta controlada del LLM, ya que exceden la gramática soportada o refieren a columnas inexistentes:

| # | Dataset | Pregunta en Lenguaje Natural | Motivo del Rechazo / Comportamiento Esperado |
|---|---|---|---|
| N.1 | `01_biblioteca.csv` | *"¿Cuál es el precio promedio de los libros?"* | **Columna inexistente:** El dataset no posee columna `precio`. No debe inventar columnas ni mapear a `anio_publicacion`. |
| N.2 | `02_recursos_humanos.csv` | *"¿Cuántos empleados de Ingeniería ganan más de 1.500.000?"* | **Filtro compuesto no soportado:** Requiere 2 condiciones (`departamento == 'Ingeniería'` AND `salario > 1500000`), pero cada filtro admite una única condición. |
| N.3 | `03_inventario.csv` | *"Calculá la mediana y la desviación estándar del stock."* | **Operación no implementada:** `median` y `stddev` no existen en el motor Go. |
| N.4 | `04_transporte.csv` | *"¿Cuál es el promedio de distancia por conductor?"* | **Agregación no soportada en `group_by`:** `group_by` solo admite `count` o `sum`, no `average`. |
| N.5 | `05_observatorio_exoplanetas.csv` | *"¿Cuál es el mejor planeta de todos?"* | **Pregunta subjetiva / ambigua:** No define métrica ni operación estructurada válida. |
| N.6 | `09_valores_problematicos.csv` | *"Sumame el monto."* | **Ambigüedad de columnas similares:** Existen `monto_bruto` y `monto_neto`. El sistema debe pedir aclaración o rechazar por ambigüedad en lugar de adivinar arbitrariamente sin avisar. |
| N.7 | `10_dataset_limite.csv` | *"¿Cuál es el promedio de `columna_vacia`?"* | **Columna totalmente vacía / sin datos numéricos:** Debe manejar división por cero o ausencia de valores numéricos sin hacer *panic* en Go. |
