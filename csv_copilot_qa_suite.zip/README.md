# Suite de Pruebas de Generalización — CSV Copilot

Conjunto independiente de **10 datasets en formato CSV** y **107 casos de prueba verificados** diseñados desde una perspectiva de Ingeniería de QA para evaluar la capacidad de generalización, detección de esquemas, parsing semántico (Qwen3 4B vía Ollama) y ejecución determinista (motor Go) de **CSV Copilot**.

---

## 1. Estructura de los Archivos Entregados

| Archivo | Dominio | Filas | Columnas | Objetivo Principal de Evaluación |
|---|---|---|---|---|
| `01_biblioteca.csv` | Catálogo Bibliográfico | 45 | 7 | Consultas sobre texto, booleanos textuales (`Si`/`No`), años y conteos únicos. |
| `02_recursos_humanos.csv` | Nómina y RR.HH. | 55 | 8 | Magnitudes salariales altas, antigüedad con ceros y agrupaciones con suma. |
| `03_inventario.csv` | Control de Stock | 60 | 7 | Precios decimales, stock en cero, filtros `lte` y búsqueda por subcadenas. |
| `04_transporte.csv` | Logística y Flota | 50 | 8 | Distancias decimales, tiempos en minutos y agrupaciones geográficas. |
| `05_observatorio_exoplanetas.csv` | Astronomía (No convencional) | 40 | 9 | Nombres técnicos poco evidentes (`masa_joviana`, `temp_equilibrio_k`) para probar cero sobreajuste. |
| `06_calidad_aire.csv` | Sensores Ambientales | 48 | 7 | Variables científicas (`pm25_ug_m3`, `pm10_ug_m3`), códigos de estación y umbrales. |
| `07_clinica_veterinaria.csv` | Salud Animal | 36 | 6 | Pesos decimales heterogéneos según especie y costos de atención. |
| `08_torneos_esports.csv` | Competencias Gaming | 52 | 8 | Métricas de audiencia masiva, premios en USD y fases de torneo. |
| `09_valores_problematicos.csv` | **Prueba de Robustez** | 35 | 8 | Celdas vacías, espacios leading/trailing, mayúsculas/minúsculas mezcladas y columnas similares (`monto_bruto`/`monto_neto`, `codigo_ref`/`codigo_revision`). |
| `10_dataset_limite.csv` | **Casos Límite (Edge Cases)** | 7 | 6 | Volumen mínimo, columna constante, columna 100% única y columna completamente vacía. |
| `CASOS_DE_PRUEBA.md` | Documentación QA | - | - | 100 consultas válidas con JSON esperado y resultado exacto + 7 pruebas negativas/ambiguas. |

---

## 2. Cómo Ejecutar la Evaluación

1. **Verificación de Carga e Inferencia de Esquema:**
   - Subí cada archivo CSV individualmente a la interfaz web de **CSV Copilot**.
   - Verificá que el detector en Go identifique correctamente columnas de texto vs. numéricas (prestando especial atención a `monto_neto` en `09_valores_problematicos.csv` que contiene celdas vacías, y a `columna_vacia` en `10_dataset_limite.csv`).
2. **Ejecución de Consultas Positivas (`CASOS_DE_PRUEBA.md`):**
   - Formulá las preguntas en lenguaje natural (o paráfrasis equivalentes) contra el modelo local **Qwen3 4B**.
   - Contrastá tanto la instrucción estructurada intermedia generada por el LLM como el resultado final devuelto por el motor Go.
   - *Nota sobre `09_valores_problematicos.csv`:* Dependiendo de si tu motor Go aplica `strings.TrimSpace` o comparación *case-insensitive* en `eq`/`contains`/`group_by`, compará contra ambos valores documentados en `CASOS_DE_PRUEBA.md`.
3. **Ejecución de Pruebas Negativas (Sección Final de `CASOS_DE_PRUEBA.md`):**
   - Ejecutá las consultas `N.1` a `N.7` para garantizar que el sistema no alucina columnas inexistentes, rechaza filtros múltiples no implementados y evita errores de división por cero o *panics* en tiempo de ejecución.
